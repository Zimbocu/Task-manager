from flask import Flask, render_template, url_for, request, redirect, session
from flask_sqlalchemy import SQLAlchemy
from datetime import datetime
import bcrypt

app = Flask(__name__)
app.secret_key = 'abcd'
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///site.db'
db = SQLAlchemy(app)

""" Veritabani modelleri """
class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(200), nullable=False)
    email = db.Column(db.String(200), nullable=False)
    password = db.Column(db.String(200), nullable=False)
    todos = db.relationship('Todo', backref='user', lazy=True)


class Todo(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    content = db.Column(db.String(200), nullable=False)
    completed = db.Column(db.Integer, default=0)
    date_created = db.Column(db.DateTime, default=datetime.now)

    def __repr__(self):
        return '<Task %r>' % self.id

""" kullanici giris yapmadiysa logine yonlendir """
@app.route('/')
def index():
    if session.get('username'):
        return redirect('/dashboard')
    else:
        return redirect('/login')

@app.route('/login', methods=['POST', 'GET'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        user = User.query.filter_by(username=username).first()
        isvalid = check_password(password, user.password) if user else False
        """ user password ile karsilastir """
        if isvalid:
            session['username'] = user.username
            session['user_id'] = user.id
            
            return redirect('/dashboard')
        
        else:
            return 'Invalid username or password'      
        
    else:
        return render_template('login.html')
    
@app.route('/logout')
def logout():
    session.clear()
    return redirect('/login')

""" veri tabanindan taks silme """
@app.route('/delete/<int:id>')  
def delete(id):
    task_to_delete = Todo.query.get_or_404(id)

    try:
        db.session.delete(task_to_delete)
        db.session.commit()
        return redirect('/')
    except:
        return 'There was a problem deleting that task'

""" task update islemi """
@app.route('/update/<int:id>', methods=['GET', 'POST'])  
def update(id):
    task = Todo.query.get_or_404(id)
    if request.method == 'POST':
        task.content = request.form['content']

        try:
            db.session.commit()
            return redirect('/')
        except:
            return 'There was an issue updating your task'
    else:
        return render_template('update.html', task=task)

""" ana panel sayfasi """
@app.route('/dashboard', methods=['POST', 'GET'])
def dashboard():
    if request.method == 'POST':
        task_content = request.form['content']
        new_task = Todo(content=task_content, user_id=session['user_id'])

        try:
            db.session.add(new_task)
            db.session.commit()
            return redirect('/')
        except:
            return 'There was an issue adding your task'
        
    else:
        tasks = Todo.query.filter_by(user_id=session['user_id']).all()
        return render_template('index.html', tasks=tasks)

""" kayit olustur sifreyi hashle """
@app.route('/register', methods=['POST', 'GET'])
def register():
    if request.method == 'POST':
        username = request.form['username']
        email = request.form['email']
        password = request.form['password']

        hashed_password = hash_password(password)
        new_user = User(username=username, email=email, password=hashed_password)

        try:
            db.session.add(new_user)
            db.session.commit()
            return redirect('/')
        except:
            return 'There was an issue registering your account'
    else:
        return render_template('register.html')
    
""" kullaniciya ait toplam task sayisi """
@app.route('/total-tasks')
def total_tasks():
    if 'user_id' not in session:
        return redirect('/login')
    
    # Count only tasks for the current user
    total = Todo.query.filter_by(user_id=session['user_id']).count()
    return render_template('total.html', total=total)

def hash_password(plain_password: str) -> str:
    hashed = bcrypt.hashpw(plain_password.encode('utf-8'), bcrypt.gensalt())
    return hashed.decode('utf-8')  # store this in DB

def check_password(plain_password: str, hashed_password: str) -> bool:
    return bcrypt.checkpw(plain_password.encode('utf-8'), hashed_password.encode('utf-8'))


if __name__ == "__main__":
    app.run(debug=True)
    """ with app.app_context():
        db.drop_all()
        db.create_all()
        print("Database created and initialized.") """

